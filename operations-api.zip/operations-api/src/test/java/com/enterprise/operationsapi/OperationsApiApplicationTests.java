package com.enterprise.operationsapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OperationsApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
