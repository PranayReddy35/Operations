package com.enterprise.operationsapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OperationsApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(OperationsApiApplication.class, args);
	}

}
